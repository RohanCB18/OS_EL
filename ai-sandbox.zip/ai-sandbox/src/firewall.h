#ifndef FIREWALL_H
#define FIREWALL_H

// Block all network traffic except loopback
int setup_firewall(void);

#endif
